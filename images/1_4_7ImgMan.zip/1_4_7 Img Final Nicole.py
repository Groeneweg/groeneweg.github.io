*original code
from PIL import *
import matplotlib.pyplot as plt # single use of plt is commented out
import os.path
import PIL.ImageDraw
from PIL import ImageFilter
from PIL import Image

import sys
from PIL import Image
im = Image.open("son.JPG")


box = (125,125,300,300)
region = im.crop(box)
region = region.transpose(Image.ROTATE_180).filter(ImageFilter.EMBOSS).convert('L')
#im1 = im.filter(ImageFilter.BLUR)
im.paste(region, box)
im.save('son.JPG')
im.show()
